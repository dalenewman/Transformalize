﻿function Double(input) {
    if (!input || input == '') {
        return '';
    }
    return input + ' ' + input;
}